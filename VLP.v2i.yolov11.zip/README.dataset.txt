# VLP > 2023-11-13 3:48pm
https://universe.roboflow.com/k-hariprasad-reddy-jmaoa/vlp-crxuo

Provided by a Roboflow user
License: CC BY 4.0

